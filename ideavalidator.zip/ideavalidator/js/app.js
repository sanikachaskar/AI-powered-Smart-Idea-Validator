// ─── STORAGE ───────────────────────────────────────────────
const DB = {
  getUsers: () => JSON.parse(localStorage.getItem('iv_users') || '{}'),
  setUsers: (u) => localStorage.setItem('iv_users', JSON.stringify(u)),
  getSession: () => JSON.parse(localStorage.getItem('iv_session') || 'null'),
  setSession: (s) => localStorage.setItem('iv_session', JSON.stringify(s)),
  clearSession: () => localStorage.removeItem('iv_session'),
  getIdeas: (uid) => JSON.parse(localStorage.getItem(`iv_ideas_${uid}`) || '[]'),
  setIdeas: (uid, ideas) => localStorage.setItem(`iv_ideas_${uid}`, JSON.stringify(ideas)),
  addIdea: (uid, idea) => {
    const ideas = DB.getIdeas(uid);
    ideas.unshift({ ...idea, id: Date.now(), createdAt: new Date().toISOString() });
    DB.setIdeas(uid, ideas);
    return ideas[0];
  },
  deleteIdea: (uid, id) => {
    const ideas = DB.getIdeas(uid).filter(i => i.id !== id);
    DB.setIdeas(uid, ideas);
  }
};

// ─── AUTH ───────────────────────────────────────────────────
const Auth = {
  register: (name, email, password) => {
    const users = DB.getUsers();
    if (users[email]) return { ok: false, error: 'Email already registered.' };
    users[email] = { name, email, password: btoa(password), createdAt: new Date().toISOString() };
    DB.setUsers(users);
    const session = { email, name, uid: btoa(email) };
    DB.setSession(session);
    return { ok: true, session };
  },
  login: (email, password) => {
    const users = DB.getUsers();
    const user = users[email];
    if (!user) return { ok: false, error: 'No account found with this email.' };
    if (user.password !== btoa(password)) return { ok: false, error: 'Incorrect password.' };
    const session = { email, name: user.name, uid: btoa(email) };
    DB.setSession(session);
    return { ok: true, session };
  },
  logout: () => { DB.clearSession(); window.location.href = '../index.html'; },
  require: () => {
    const s = DB.getSession();
    if (!s) { window.location.href = '../pages/auth.html'; return null; }
    return s;
  },
  redirect: () => {
    const s = DB.getSession();
    if (s) window.location.href = '../pages/dashboard.html';
  }
};

// ─── TOAST ──────────────────────────────────────────────────
function showToast(msg, duration = 3000) {
  let t = document.getElementById('toast');
  if (!t) { t = document.createElement('div'); t.id = 'toast'; document.body.appendChild(t); }
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove('show'), duration);
}

// ─── SCORE HELPERS ──────────────────────────────────────────
function scoreColor(s) {
  if (s >= 75) return '#10B981';
  if (s >= 50) return '#F59E0B';
  return '#EF4444';
}

function scoreVerdict(s) {
  if (s >= 80) return { label: 'Strong', cls: 'badge-green' };
  if (s >= 60) return { label: 'Promising', cls: 'badge-blue' };
  if (s >= 40) return { label: 'Needs Work', cls: 'badge-amber' };
  return { label: 'Risky', cls: 'badge-red' };
}

function renderScoreRing(score, size = 88) {
  const r = size / 2 - 8;
  const circ = 2 * Math.PI * r;
  const offset = circ - (score / 100) * circ;
  const col = scoreColor(score);
  return `<div class="score-ring-wrap" style="width:${size}px;height:${size}px;">
    <svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
      <circle cx="${size/2}" cy="${size/2}" r="${r}" fill="none" stroke="rgba(255,255,255,0.07)" stroke-width="6"/>
      <circle cx="${size/2}" cy="${size/2}" r="${r}" fill="none" stroke="${col}" stroke-width="6"
        stroke-dasharray="${circ}" stroke-dashoffset="${offset}" stroke-linecap="round"/>
    </svg>
    <div class="score-ring-center">
      <span class="score-ring-num" style="color:${col}">${score}</span>
      <span class="score-ring-label">/100</span>
    </div>
  </div>`;
}

function renderMetricBar(label, value) {
  const col = scoreColor(value);
  return `<div>
    <div class="flex justify-between items-center mb-1">
      <span class="text-sm" style="color:var(--text-2)">${label}</span>
      <span class="text-sm font-500" style="color:${col}">${value}</span>
    </div>
    <div class="progress-bar">
      <div class="progress-fill" style="width:${value}%;background:${col}"></div>
    </div>
  </div>`;
}

// ─── COPY TO CLIPBOARD ──────────────────────────────────────
async function copyText(text) {
  try { await navigator.clipboard.writeText(text); showToast('Copied to clipboard!'); }
  catch { showToast('Could not copy.'); }
}

// ─── RELATIVE TIME ──────────────────────────────────────────
function timeAgo(iso) {
  const diff = (Date.now() - new Date(iso)) / 1000;
  if (diff < 60) return 'just now';
  if (diff < 3600) return `${Math.floor(diff/60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff/3600)}h ago`;
  if (diff < 604800) return `${Math.floor(diff/86400)}d ago`;
  return new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

// ─── CLAUDE API ─────────────────────────────────────────────
async function callClaude(prompt) {
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1000,
      messages: [{ role: 'user', content: prompt }]
    })
  });
  const data = await res.json();
  const text = data.content.map(b => b.text || '').join('');
  return text.replace(/```json|```/g, '').trim();
}
