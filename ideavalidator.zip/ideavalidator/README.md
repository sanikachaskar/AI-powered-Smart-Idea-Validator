# IdeaValidate — AI Startup Idea Analyzer

A full-featured web app for validating startup ideas using Claude AI.

## Project Structure

```
ideavalidator/
├── index.html              # Landing page
├── css/
│   └── style.css           # Design system & global styles
├── js/
│   └── app.js              # Auth, storage, utilities, Claude API
└── pages/
    ├── auth.html           # Login & Register
    ├── dashboard.html      # Ideas history & stats
    └── analyzer.html       # Submit & view full analysis
```

## Features

- **Landing page** — Professional marketing page with hero, features, and how-it-works
- **Auth** — Register / Login with demo account pre-seeded with sample ideas
- **Analyzer** — Submit idea, pick business type, get AI analysis with:
  - Overall score (0–100) with animated ring
  - 5-dimension metric bars (market, problem clarity, competitive edge, execution, revenue)
  - Strengths / Risks / Opportunities tags
  - Actionable recommendation from Claude
  - Copy & Share report
- **Dashboard** — View all saved analyses with:
  - Stats: total ideas, average score, best idea, count of strong ideas
  - Search and sort
  - Delete individual analyses
  - Quick share via clipboard

## Tech Stack

- Pure HTML, CSS, JavaScript (no build tools or frameworks required)
- Google Fonts: DM Serif Display + DM Sans
- Claude AI via Anthropic API (claude-sonnet-4-20250514)
- localStorage for data persistence

## How to Run

Simply open `index.html` in any modern browser — or serve from any static file server:

```bash
# Python (from project folder)
python3 -m http.server 8080

# Node (npx)
npx serve .
```

Then visit `http://localhost:8080`

## Demo Account

Click "Continue with demo account" on the login page to instantly load a pre-seeded account with 2 sample analyses.

## Notes

- All data is stored in browser localStorage (no backend required)
- The Anthropic API is called directly from the browser (requires the hosted claude.ai environment for API access)
- To use in your own environment, add your API key to the `callClaude()` function in `js/app.js`
