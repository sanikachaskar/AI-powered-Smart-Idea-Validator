# IdeaLens — AI Startup Idea Validator

A clean, minimal web app that lets you validate startup ideas using Claude AI.

## Features
- **User accounts** — sign up / sign in, stored in localStorage
- **AI analysis** — powered by Claude (Anthropic API) with viability scoring
- **Dashboard** — view, expand, and manage all past analyses
- **Share results** — copy a formatted plain-text report to clipboard
- **No backend needed** — runs entirely in the browser

## Project Structure
```
ideavalidator/
├── index.html        # App shell + auth screen
├── css/
│   └── style.css     # All styles (clean minimal design)
└── js/
    ├── auth.js       # Login / register / session
    ├── app.js        # Navigation, toast, share modal
    ├── analyze.js    # AI call + result rendering
    └── dashboard.js  # Saved ideas grid + detail view
```

## How to run
1. Open `index.html` in any modern browser (Chrome, Firefox, Safari, Edge).
2. No build step, no server needed — just open the file.
3. The Anthropic API key is injected automatically by the claude.ai environment.

## API
Uses `https://api.anthropic.com/v1/messages` with `claude-sonnet-4-20250514`.
The API key is handled by the claude.ai sandbox — no key setup required when running inside an artifact.

If running locally outside claude.ai, add your API key to the fetch headers in `js/analyze.js`:
```js
headers: {
  'Content-Type': 'application/json',
  'x-api-key': 'YOUR_API_KEY',
  'anthropic-version': '2023-06-01',
  'anthropic-dangerous-direct-browser-access': 'true'
}
```

## Demo login
Enter any email + password on the login screen — it will auto-create an account in demo mode.
