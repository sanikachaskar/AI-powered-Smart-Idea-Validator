// ── Auth ──
// Simple localStorage-based auth for demo purposes

function switchTab(tab) {
  document.querySelectorAll('.tab-btn').forEach((b, i) => {
    b.classList.toggle('active', (i === 0 && tab === 'login') || (i === 1 && tab === 'register'));
  });
  document.getElementById('loginForm').style.display = tab === 'login' ? 'block' : 'none';
  document.getElementById('registerForm').style.display = tab === 'register' ? 'block' : 'none';
}

function handleLogin() {
  const email = document.getElementById('loginEmail').value.trim();
  const pass  = document.getElementById('loginPass').value;
  if (!email || !pass) return showToast('Please fill in all fields.');
  if (!email.includes('@')) return showToast('Enter a valid email.');
  if (pass.length < 3) return showToast('Password too short.');

  // Check registered users first, else create a session anyway (demo mode)
  const users = JSON.parse(localStorage.getItem('il_users') || '[]');
  let user = users.find(u => u.email === email);
  if (!user) {
    // Auto-register in demo mode
    user = { id: Date.now().toString(), name: email.split('@')[0], email, pass };
    users.push(user);
    localStorage.setItem('il_users', JSON.stringify(users));
  }
  if (user.pass !== pass) return showToast('Incorrect password.');

  localStorage.setItem('il_session', JSON.stringify({ id: user.id, name: user.name, email: user.email }));
  bootApp(user);
}

function handleRegister() {
  const name  = document.getElementById('regName').value.trim();
  const email = document.getElementById('regEmail').value.trim();
  const pass  = document.getElementById('regPass').value;
  if (!name || !email || !pass) return showToast('Please fill in all fields.');
  if (!email.includes('@')) return showToast('Enter a valid email.');
  if (pass.length < 6) return showToast('Password must be at least 6 characters.');

  const users = JSON.parse(localStorage.getItem('il_users') || '[]');
  if (users.find(u => u.email === email)) return showToast('An account with this email already exists.');

  const user = { id: Date.now().toString(), name, email, pass };
  users.push(user);
  localStorage.setItem('il_users', JSON.stringify(users));
  localStorage.setItem('il_session', JSON.stringify({ id: user.id, name: user.name, email: user.email }));
  bootApp(user);
}

function signOut() {
  localStorage.removeItem('il_session');
  document.getElementById('appShell').style.display = 'none';
  document.getElementById('authScreen').style.display = 'block';
}

function checkSession() {
  const session = localStorage.getItem('il_session');
  if (session) {
    bootApp(JSON.parse(session));
  }
}

function bootApp(user) {
  document.getElementById('authScreen').style.display = 'none';
  document.getElementById('appShell').style.display = 'flex';
  document.getElementById('userName').textContent = user.name;
  document.getElementById('userEmail').textContent = user.email;
  document.getElementById('userAvatar').textContent = user.name[0].toUpperCase();
  window._currentUser = user;
  renderDashboard();
}

// Init on load
document.addEventListener('DOMContentLoaded', checkSession);
