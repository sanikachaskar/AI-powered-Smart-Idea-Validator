// ── Dashboard ──

function getUserIdeas() {
  if (!window._currentUser) return [];
  const key = 'il_ideas_' + window._currentUser.id;
  return JSON.parse(localStorage.getItem(key) || '[]');
}

function deleteIdea(id, e) {
  e.stopPropagation();
  if (!window._currentUser) return;
  const key = 'il_ideas_' + window._currentUser.id;
  const ideas = getUserIdeas().filter(i => i._id !== id);
  localStorage.setItem(key, JSON.stringify(ideas));
  renderDashboard();
  showToast('Idea removed.');
}

function renderDashboard() {
  const container = document.getElementById('dashboardContent');
  if (!container) return;

  const ideas = getUserIdeas();

  if (!ideas.length) {
    container.innerHTML = `
      <div class="empty-state">
        <h3>No ideas yet</h3>
        <p>Run your first analysis and it will appear here.</p>
        <button class="btn-primary" onclick="showPage('analyze', document.querySelector('.nav-item'))">Analyze an idea</button>
      </div>`;
    return;
  }

  const stats = computeStats(ideas);
  container.innerHTML = renderStats(stats) + renderIdeaCards(ideas);
}

function computeStats(ideas) {
  const avg = arr => Math.round(arr.reduce((a, b) => a + b, 0) / arr.length);
  const scores = ideas.map(i => i.overall_score);
  const verdicts = ideas.reduce((acc, i) => { acc[i.verdict] = (acc[i.verdict] || 0) + 1; return acc; }, {});
  const topVerdict = Object.entries(verdicts).sort((a,b) => b[1]-a[1])[0]?.[0] || '—';
  return {
    count: ideas.length,
    avgScore: avg(scores),
    best: Math.max(...scores),
    topVerdict
  };
}

function renderStats(s) {
  const statColor = (val) => {
    const c = scoreColors(val);
    return c.text;
  };
  return `
    <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(140px,1fr)); gap:8px; margin-bottom:1.5rem;">
      <div class="metric-tile">
        <div class="mt-label">Total ideas</div>
        <div class="mt-val" style="font-size:22px; margin-top:4px;">${s.count}</div>
      </div>
      <div class="metric-tile">
        <div class="mt-label">Average score</div>
        <div class="mt-val" style="font-size:22px; margin-top:4px; color:${statColor(s.avgScore)};">${s.avgScore}</div>
      </div>
      <div class="metric-tile">
        <div class="mt-label">Best score</div>
        <div class="mt-val" style="font-size:22px; margin-top:4px; color:${statColor(s.best)};">${s.best}</div>
      </div>
      <div class="metric-tile">
        <div class="mt-label">Top verdict</div>
        <div class="mt-val" style="font-size:15px; margin-top:4px;">${s.topVerdict}</div>
      </div>
    </div>
  `;
}

function renderIdeaCards(ideas) {
  return `<div class="ideas-grid">${ideas.map(idea => renderIdeaCard(idea)).join('')}</div>`;
}

function scoreColors(s) {
  if (s >= 72) return { border: '#166534', text: '#166534', bg: '#dcfce7', fill: '#16a34a' };
  if (s >= 48) return { border: '#92400e', text: '#92400e', bg: '#fef3c7', fill: '#d97706' };
  return { border: '#991b1b', text: '#991b1b', bg: '#fee2e2', fill: '#dc2626' };
}

function renderIdeaCard(d) {
  const c = scoreColors(d.overall_score);
  const dateStr = d._date ? new Date(d._date).toLocaleDateString('en-IN', { day:'numeric', month:'short' }) : '';
  const chips = (d._chips || []).map(ch => `<span class="idea-tag-mini">${ch}</span>`).join('');

  return `
    <div class="idea-card" onclick="expandIdeaCard('${d._id}')">
      <div class="idea-card-top">
        <span class="idea-card-name">${d.name}</span>
        <span class="idea-score-badge" style="color:${c.text}; background:${c.bg}; border-color:${c.bg};">${d.overall_score}</span>
      </div>
      <p class="idea-card-preview">${d._idea || d.tagline}</p>
      <div class="idea-card-footer">
        <span class="idea-date">${dateStr}</span>
        <div style="display:flex; align-items:center; gap:6px;">
          ${chips}
          <button class="btn-ghost" style="padding:3px 8px; font-size:11px;" onclick="deleteIdea('${d._id}', event)">Remove</button>
          <button class="btn-ghost" style="padding:3px 8px; font-size:11px;" onclick="shareFromDash('${d._id}', event)">Share</button>
        </div>
      </div>
    </div>
  `;
}

function expandIdeaCard(id) {
  const ideas = getUserIdeas();
  const d = ideas.find(i => i._id === id);
  if (!d) return;

  // Show a detail modal-like view by replacing the page content temporarily
  const container = document.getElementById('dashboardContent');
  const c = scoreColors(d.overall_score);
  const dateStr = d._date ? new Date(d._date).toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' }) : '';
  const metricDefs = [
    { key: 'market_size', label: 'Market size' },
    { key: 'problem_clarity', label: 'Problem clarity' },
    { key: 'competitive_edge', label: 'Competitive edge' },
    { key: 'revenue_potential', label: 'Revenue potential' },
    { key: 'execution_difficulty', label: 'Exec. difficulty', invert: true },
  ];
  const metricsHtml = metricDefs.map(m => {
    const raw = d.metrics[m.key] || 0;
    const display = m.invert ? 100 - raw : raw;
    const mc = scoreColors(display);
    return `<div class="metric-tile">
      <div class="mt-label">${m.label}</div>
      <div class="mt-bar"><div class="mt-fill" style="width:${display}%; background:${mc.fill};"></div></div>
      <div class="mt-val">${display}/100</div>
    </div>`;
  }).join('');

  const strengths = d.strengths.map(s => `<span class="tag tag-green">${s}</span>`).join('');
  const risks     = d.risks.map(r => `<span class="tag tag-red">${r}</span>`).join('');
  const opps      = d.opportunities.map(o => `<span class="tag tag-amber">${o}</span>`).join('');

  container.innerHTML = `
    <div class="fade-in">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem; flex-wrap:wrap; gap:8px;">
        <button class="btn-ghost" onclick="renderDashboard()">
          <svg width="13" height="13" viewBox="0 0 13 13" fill="none"><path d="M8 2L3 6.5 8 11" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>
          Back to all ideas
        </button>
        <div style="display:flex;gap:8px;">
          <button class="btn-ghost" onclick="shareFromDash('${d._id}', event)">
            <svg width="13" height="13" viewBox="0 0 13 13" fill="none"><circle cx="10" cy="2" r="1.5" stroke="currentColor" stroke-width="1.2"/><circle cx="10" cy="11" r="1.5" stroke="currentColor" stroke-width="1.2"/><circle cx="2" cy="6.5" r="1.5" stroke="currentColor" stroke-width="1.2"/><path d="M3.4 5.8L8.6 3m0 7L3.4 7.2" stroke="currentColor" stroke-width="1.2"/></svg>
            Share
          </button>
          <button class="btn-ghost" onclick="deleteIdea('${d._id}', event)">Remove</button>
        </div>
      </div>

      <div class="result-header">
        <div>
          <h2 style="font-family:var(--font-display); font-size:22px; font-weight:400;">${d.name}</h2>
          <span style="font-size:12px; color:var(--text3);">${dateStr}</span>
        </div>
      </div>

      <div class="score-banner">
        <div class="score-ring" style="border-color:${c.border}; background:${c.bg};">
          <span class="score-num" style="color:${c.text};">${d.overall_score}</span>
          <span class="score-lbl" style="color:${c.text};">/ 100</span>
        </div>
        <div class="score-meta">
          <h2>${d.name} <span class="verdict-pill" style="background:${c.bg}; color:${c.text};">${d.verdict}</span></h2>
          <p>${d.tagline}</p>
          ${d.comparable_to ? `<p style="font-size:13px; margin-top:4px; color:var(--text3);">Think: <em>${d.comparable_to}</em></p>` : ''}
        </div>
      </div>

      <div class="metrics-grid">${metricsHtml}</div>

      <div class="tags-section"><h3>Strengths</h3>${strengths}</div>
      <div class="tags-section"><h3>Risks</h3>${risks}</div>
      <div class="tags-section"><h3>Opportunities</h3>${opps}</div>

      <div class="reco-card">
        <h3>Recommendation</h3>
        <p>${d.recommendation}</p>
      </div>

      ${d._idea ? `<div class="card" style="margin-top:1rem;"><p style="font-size:13px; color:var(--text2); line-height:1.7;"><strong style="font-size:11px; text-transform:uppercase; letter-spacing:.06em; color:var(--text3);">Original idea</strong><br/>${d._idea}</p></div>` : ''}
    </div>
  `;
}

function shareFromDash(id, e) {
  e.stopPropagation();
  const ideas = getUserIdeas();
  const d = ideas.find(i => i._id === id);
  if (d) openShareModal(d);
}
