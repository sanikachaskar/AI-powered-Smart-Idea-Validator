// ── Analyze ──

const EXAMPLES = [
  "A mobile app that uses AI to scan your pantry and fridge via photos, suggests personalized recipes based on what you have, tracks nutritional intake, and auto-generates a grocery list for missing ingredients with one-tap delivery integration.",
  "A B2B SaaS platform that helps remote engineering teams cut meeting fatigue by 60% — using AI to auto-summarize async video updates, flag action items, and surface only the decisions that genuinely require a sync discussion.",
  "A subscription rental service for premium ergonomic office furniture and equipment, targeting remote workers with flexible monthly plans, free swap-outs every 6 months, and white-glove delivery & setup included."
];

let activeChips = [];

function toggleChip(el, val) {
  el.classList.toggle('active');
  if (activeChips.includes(val)) activeChips = activeChips.filter(c => c !== val);
  else activeChips.push(val);
}

function loadExample() {
  const text = EXAMPLES[Math.floor(Math.random() * EXAMPLES.length)];
  const ta = document.getElementById('ideaInput');
  ta.value = text;
  document.getElementById('charCount').textContent = text.length + ' / 600';
}

document.addEventListener('DOMContentLoaded', () => {
  const ta = document.getElementById('ideaInput');
  if (ta) {
    ta.addEventListener('input', () => {
      document.getElementById('charCount').textContent = ta.value.length + ' / 600';
    });
  }
});

async function analyzeIdea() {
  const idea = document.getElementById('ideaInput').value.trim();
  if (!idea || idea.length < 20) return showToast('Please describe your idea in at least a sentence or two.');

  const btn = document.getElementById('analyzeBtn');
  btn.disabled = true;
  btn.innerHTML = '<div class="spinner"></div> Analyzing…';

  const resultArea = document.getElementById('resultArea');
  resultArea.style.display = 'block';
  resultArea.innerHTML = '<p class="muted" style="font-size:14px; padding:1rem 0;">Running AI analysis — this takes a few seconds…</p>';

  const focus = activeChips.length ? `Business model context: ${activeChips.join(', ')}.` : '';

  const prompt = `You are a world-class startup analyst and venture capital advisor with deep experience evaluating thousands of startups. Analyze the following startup idea thoroughly and return ONLY a valid JSON object — no markdown, no code fences, no extra text whatsoever.

Idea: "${idea}"
${focus}

Return exactly this JSON structure:
{
  "name": "Short catchy product name (2-4 words)",
  "verdict": "one of: Strong | Promising | Needs Work | Risky",
  "overall_score": integer between 1 and 100,
  "tagline": "One compelling sentence capturing the core opportunity or key risk",
  "comparable_to": "e.g. Airbnb for X, or leave empty string if not applicable",
  "metrics": {
    "market_size": integer 1-100,
    "problem_clarity": integer 1-100,
    "competitive_edge": integer 1-100,
    "execution_difficulty": integer 1-100,
    "revenue_potential": integer 1-100
  },
  "strengths": ["strength one, max 9 words", "strength two, max 9 words", "strength three, max 9 words"],
  "risks": ["risk one, max 9 words", "risk two, max 9 words", "risk three, max 9 words"],
  "opportunities": ["opportunity one, max 9 words", "opportunity two, max 9 words"],
  "recommendation": "2-3 sentences of specific, actionable next steps for the founder to validate or improve this idea."
}`;

  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        messages: [{ role: 'user', content: prompt }]
      })
    });
    const data = await res.json();
    const raw  = data.content.map(b => b.text || '').join('');
    const clean = raw.replace(/```json|```/g, '').trim();
    const result = JSON.parse(clean);

    // Attach metadata
    result._idea = idea;
    result._chips = [...activeChips];
    result._date = new Date().toISOString();
    result._id = Date.now().toString();

    saveResult(result);
    renderResult(result, resultArea);
  } catch(e) {
    resultArea.innerHTML = '<p style="color:#991b1b; font-size:14px; padding:1rem 0;">Analysis failed — please try again.</p>';
  }

  btn.disabled = false;
  btn.innerHTML = '<svg width="15" height="15" viewBox="0 0 15 15" fill="none"><path d="M7.5 1v2M7.5 12v2M1 7.5h2M12 7.5h2M3.2 3.2l1.4 1.4M10.4 10.4l1.4 1.4M3.2 11.8l1.4-1.4M10.4 4.6l1.4-1.4" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg> Run analysis';
}

function saveResult(result) {
  if (!window._currentUser) return;
  const key = 'il_ideas_' + window._currentUser.id;
  const ideas = JSON.parse(localStorage.getItem(key) || '[]');
  // Avoid duplicates by id
  const filtered = ideas.filter(i => i._id !== result._id);
  filtered.unshift(result);
  localStorage.setItem(key, JSON.stringify(filtered.slice(0, 50)));
}

function scoreColors(s) {
  if (s >= 72) return { border: '#166534', text: '#166534', bg: '#dcfce7', fill: '#16a34a' };
  if (s >= 48) return { border: '#92400e', text: '#92400e', bg: '#fef3c7', fill: '#d97706' };
  return { border: '#991b1b', text: '#991b1b', bg: '#fee2e2', fill: '#dc2626' };
}

function renderResult(d, container) {
  const c = scoreColors(d.overall_score);
  const metricDefs = [
    { key: 'market_size',         label: 'Market size' },
    { key: 'problem_clarity',     label: 'Problem clarity' },
    { key: 'competitive_edge',    label: 'Competitive edge' },
    { key: 'revenue_potential',   label: 'Revenue potential' },
    { key: 'execution_difficulty',label: 'Exec. difficulty', invert: true },
  ];

  const metricsHtml = metricDefs.map(m => {
    const raw = d.metrics[m.key] || 0;
    const display = m.invert ? 100 - raw : raw;
    const mc = scoreColors(display);
    return `<div class="metric-tile">
      <div class="mt-label">${m.label}</div>
      <div class="mt-bar"><div class="mt-fill" style="width:${display}%; background:${mc.fill};"></div></div>
      <div class="mt-val">${display}/100</div>
    </div>`;
  }).join('');

  const strengths   = d.strengths.map(s => `<span class="tag tag-green">${s}</span>`).join('');
  const risks       = d.risks.map(r => `<span class="tag tag-red">${r}</span>`).join('');
  const opps        = d.opportunities.map(o => `<span class="tag tag-amber">${o}</span>`).join('');
  const dateStr     = d._date ? new Date(d._date).toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' }) : '';

  container.innerHTML = `
    <div class="fade-in">
      <div class="result-header">
        <div>
          <h2 style="font-family:var(--font-display); font-size:22px; font-weight:400;">${d.name}</h2>
          <span style="font-size:12px; color:var(--text3);">${dateStr}</span>
        </div>
        <div class="result-actions">
          <button class="btn-ghost" onclick="openShareModal(window._lastResult)">
            <svg width="13" height="13" viewBox="0 0 13 13" fill="none"><circle cx="10" cy="2" r="1.5" stroke="currentColor" stroke-width="1.2"/><circle cx="10" cy="11" r="1.5" stroke="currentColor" stroke-width="1.2"/><circle cx="2" cy="6.5" r="1.5" stroke="currentColor" stroke-width="1.2"/><path d="M3.4 5.8L8.6 3m0 7L3.4 7.2" stroke="currentColor" stroke-width="1.2"/></svg>
            Share
          </button>
        </div>
      </div>

      <div class="score-banner">
        <div class="score-ring" style="border-color:${c.border}; background:${c.bg};">
          <span class="score-num" style="color:${c.text};">${d.overall_score}</span>
          <span class="score-lbl" style="color:${c.text};">/ 100</span>
        </div>
        <div class="score-meta">
          <h2>${d.name} <span class="verdict-pill" style="background:${c.bg}; color:${c.text};">${d.verdict}</span></h2>
          <p>${d.tagline}</p>
          ${d.comparable_to ? `<p style="font-size:13px; margin-top:4px; color:var(--text3);">Think: <em>${d.comparable_to}</em></p>` : ''}
        </div>
      </div>

      <div class="metrics-grid">${metricsHtml}</div>

      <div class="tags-section">
        <h3>Strengths</h3>
        ${strengths}
      </div>

      <div class="tags-section">
        <h3>Risks</h3>
        ${risks}
      </div>

      <div class="tags-section">
        <h3>Opportunities</h3>
        ${opps}
      </div>

      <div class="reco-card">
        <h3>Recommendation</h3>
        <p>${d.recommendation}</p>
      </div>
    </div>
  `;

  window._lastResult = d;
  container.style.display = 'block';
  container.scrollIntoView({ behavior: 'smooth', block: 'start' });
}
